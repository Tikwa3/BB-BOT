import discord
from discord.ext import commands
import os, random
from discord.ext import tasks
import datetime 
from credits import TOKEN

intents = discord.Intents.default()
bot = commands.Bot(command_prefix='$', intents=intents)
bot = commands.Bot(command_prefix='$',intents = discord.Intents.all())
reminders = []
todo_list = {}

@bot.event
async def on_ready():
    check_reminders.start()
    print(f'We have logged in as {bot.user}')

@bot.event
async def help1(ctx):
    await ctx.send(f'ай эм BB я могу: подкинуть рецепты если мозги не ВАРЯТ)))). в то же время отправить сообщение когда макарошки сварятся. хелпануть помнить всё и всегда. и вообще я крутой. как и ты бро))')

@bot.command(name='setreminder')
async def set_reminder(ctx, time, *, reminder):
    # Распарсим время из аргумента в формат "чч:мм"
    try:
        reminder_time = datetime.datetime.strptime(time, '%H:%M').time()
    except ValueError:
        return await ctx.send("Ошибка в формате времени! Используйте формат ЧЧ:ММ (например, 12:30).")

    curr_time = datetime.datetime.now().time()

    # Проверим, не прошло ли уже указанное время
    if curr_time > reminder_time:
        return await ctx.send("Время для напоминания уже прошло!")

    # Добавим напоминание в список
    reminders.append((ctx.author.id, reminder_time, reminder))
    await ctx.send(f'Напоминание успешно установлено на {time}: {reminder}')


@tasks.loop(seconds=10)
async def check_reminders():
    current_time = datetime.datetime.now().time()

    for reminder in reminders:
        user_id, reminder_time, reminder_text = reminder
        if current_time > reminder_time:
            user = await bot.fetch_user(user_id)
            await user.send(f'Напоминание: {reminder_text}')
    
    # Очистим список от выполненных напоминаний
    reminders[:] = [r for r in reminders if current_time <= r[1]]

@bot.command(name='addtodo')
async def add_todo(ctx, *, todo_item):
    # Добавляем дело в список
    todo_list[ctx.author.id] = todo_list.get(ctx.author.id, []) + [todo_item]
    await ctx.send(f'Дело добавлено в список: {todo_item}')

@bot.command(name='showlist')
async def show_list(ctx):
    # Показываем список дел для пользователя
    user_todos = todo_list.get(ctx.author.id, [])
    if user_todos:
        todos = "\n".join([f'{index + 1}. {todo}' for index, todo in enumerate(user_todos)])
        await ctx.send(f'Ваш список дел:\n{todos}')
    else:
        await ctx.send('У вас пока нет дел в списке.')

@bot.command(name='removetodo')
async def remove_todo(ctx, item_number: int):
    # Удаляем дело из списка
    user_todos = todo_list.get(ctx.author.id, [])
    if 1 <= item_number <= len(user_todos):
        removed_item = user_todos.pop(item_number - 1)
        await ctx.send(f'Удалено из списка: {removed_item}')
    else:
        await ctx.send('Некорректный номер дела.')

    
@bot.event
async def hello(ctx):
    await ctx.send(f'ВАСАБ. Я хелпую)))')


@bot.command('eda')
async def eda(ctx):
    img = random.choice(os.listdir("receepts"))
    with open(f'receepts/{img}', 'rb') as f:
        picture = discord.File(f)
    await ctx.send(file=picture)

@bot.command(name='spisok')
async def print_list(ctx):
    if not spisok:
        await ctx.send('Список пуст!')
    else:
        await ctx.send(f'{spisok}')

@bot.command(name='add')
async def add_game(context):
    todo_list[ctx.author.id] = todo_list.get(ctx.author.id, []) + [todo_item]
    await context.send('список обнавлён')

@bot.command(name='delite')
async def add_game(context):
    spisok.pop()
    await context.send('последний элемент списка удалён')


bot.run("")



# intents = discord.Intents.default()

# bot = commands.Bot(command_prefix='!', intents=intents)

# # Список для хранения напоминаний
# reminders = []
# todo_list = {}
# @bot.event
# async def on_ready():
#     print(f'We have logged in as {bot.user}')

# @bot.command(name='setreminder')
# async def set_reminder(ctx, time, *, reminder):
#     # Распарсим время из аргумента в формат "чч:мм"
#     try:
#         reminder_time = datetime.datetime.strptime(time, '%H:%M').time()
#     except ValueError:
#         return await ctx.send("Ошибка в формате времени! Используйте формат ЧЧ:ММ (например, 12:30).")

#     curr_time = datetime.datetime.now().time()

#     # Проверим, не прошло ли уже указанное время
#     if curr_time > reminder_time:
#         return await ctx.send("Время для напоминания уже прошло!")

#     # Добавим напоминание в список
#     reminders.append((ctx.author.id, reminder_time, reminder))
#     await ctx.send(f'Напоминание успешно установлено на {time}: {reminder}')


# @tasks.loop(minutes=1)
# async def check_reminders():
#     current_time = datetime.datetime.now().time()

#     for reminder in reminders:
#         user_id, reminder_time, reminder_text = reminder
#         if current_time > reminder_time:
#             user = await bot.fetch_user(user_id)
#             await user.send(f'Напоминание: {reminder_text}')
    
#     # Очистим список от выполненных напоминаний
#     reminders[:] = [r for r in reminders if current_time <= r[1]]

# @bot.command(name='addtodo')
# async def add_todo(ctx, *, todo_item):
#     # Добавляем дело в список
#     todo_list[ctx.author.id] = todo_list.get(ctx.author.id, []) + [todo_item]
#     await ctx.send(f'Дело добавлено в список: {todo_item}')

# @bot.command(name='showlist')
# async def show_list(ctx):
#     # Показываем список дел для пользователя
#     user_todos = todo_list.get(ctx.author.id, [])
#     if user_todos:
#         todos = "\n".join([f'{index + 1}. {todo}' for index, todo in enumerate(user_todos)])
#         await ctx.send(f'Ваш список дел:\n{todos}')
#     else:
#         await ctx.send('У вас пока нет дел в списке.')

# @bot.command(name='removetodo')
# async def remove_todo(ctx, item_number: int):
#     # Удаляем дело из списка
#     user_todos = todo_list.get(ctx.author.id, [])
#     if 1 <= item_number <= len(user_todos):
#         removed_item = user_todos.pop(item_number - 1)
#         await ctx.send(f'Удалено из списка: {removed_item}')
#     else:
#         await ctx.send('Некорректный номер дела.')

# check_reminders.start()